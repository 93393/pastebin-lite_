# Pastebin Lite

Run locally:
npm install
npm run dev

Uses Vercel KV for persistence.