export default function Home() {
  return <main style={{ padding: 40 }}><h1>Pastebin Lite</h1></main>;
}